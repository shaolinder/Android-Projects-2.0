const express = require("express");
const path = require("path");
const loginRoute = require("./back/login");
const studentsRoute = require("./back/students");
require("dotenv").config();

const app = express();
const port = process.env.PORT || 4321;

app.use(express.static(path.join(__dirname, "front")));
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

app.use("/back/login", loginRoute);
app.use("/back/students", studentsRoute);

app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "front", "index.html"));
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
