$(document).ready(function() {
    $('#registrationForm').submit(function(event) {
        event.preventDefault(); // Prevent the default form submission
        
        // Get the form data
        var username = $('#username').val();
        var password = $('#password').val();

        // Send the data to the server
        $.ajax({
            type: 'POST',
            url: 'front/register', // Assuming your registration route is '/register'
            data: { username: username, password: password },
            success: function(response) {
                alert(response.message); // Show success or error message
                // You can redirect to another page after successful registration if needed
            },
            error: function(xhr, status, error) {
                console.error('Error:', error);
                alert('An error occurred while registering');
            }
        });
    });
});
