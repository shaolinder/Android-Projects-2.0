const express = require("express");
const router = express.Router();
const mysql = require("mysql");
require("dotenv").config();

const db = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
});

router.post("/", (req, res) => {
    const { username, password } = req.body;
    const sql = "SELECT * FROM students WHERE username = ? AND password = ?";
    db.query(sql, [username, password], (err, results) => {
        if (err) {
            console.error("Error authenticating user:", err);
            res.status(500).json({ success: false, message: "Internal server error" });
        } else if (results.length > 0) {
            res.status(200).json({ success: true, message: "Login successful" });
        } else {
            res.status(401).json({ success: false, message: "Invalid credentials" });
        }
    });
});

module.exports = router;
