const express = require("express");
const router = express.Router();
const mysql = require("mysql");
require("dotenv").config();

const db = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
});

router.get("/", (req, res) => {
    let sql = "SELECT * FROM students";
    db.query(sql, (err, results, fields) => {
        if (err) {
            console.log({ error: err });
            res.status(500).json(err);
        } else {
            res.status(200).json(results);
        }
    });
});

router.post("/", (req, res) => {
    const { username, password } = req.body;
    const sql = "INSERT INTO students (username, password) VALUES (?, ?)";
    db.query(sql, [username, password], (err, results) => {
        if (err) {
            console.error("Error registering user:", err);
            res.status(500).json({ success: false, message: "Internal server error" });
        } else {
            res.status(200).json({ success: true, message: "Registration successful" });
        }
    });
});


module.exports = router;
